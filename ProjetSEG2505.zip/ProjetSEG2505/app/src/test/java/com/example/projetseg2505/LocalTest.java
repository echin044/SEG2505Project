package com.example.localtests;

import org.junit.Test;
import static org.junit.Assert.*;

public class LocalTest {
    @Test
    public void emailValidation() {
        assertEquals("Email must follow format name@email.extension",true, MainActivity.isValidEmail("name@email.com"));
    }

    @Test
    public void firstNameValidation() {
        assertEquals("Name must contain only letters",true, MainActivity.isValidName("Jacob"));
    }

    @Test
    public void lastMameValidation() {
        assertEquals("Name must contain only letters",true, MainActivity.isValidName("Johnson"));
    }

    @Test
    public void passwordValidation() {
        assertEquals("Password is too weak",true, MainActivity.isValidPassword("abc1234567"));
    }

    @Test
    public void AgeValidation() {
        assertEquals("Age must be superior to 0",true, MainActivity.isValidAge(10));
    }
}

