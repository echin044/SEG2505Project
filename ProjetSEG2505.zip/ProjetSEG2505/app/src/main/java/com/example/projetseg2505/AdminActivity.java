package com.example.projetseg2505;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class AdminActivity extends AppCompatActivity {
    Administrateur compte;
    String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        //Prend le nom d'utilisateur venant du activity précédant puis l'ajoute au TextView à l'écran.
        username = getIntent().getStringExtra("username");
        TextView text = (TextView) findViewById(R.id.txtvWelcome);
        text.setText("Bienvenue " + username + "! Vous êtes connecté en tant qu'administrateur.");
        compte = new Administrateur(username, "123admin456"); //Ceci doit être changer!

    }

    public void onClickModify(View view){
        Intent intent = new Intent(getApplicationContext(), ServiceListActivity.class);
        startActivity(intent);
    }

    public void onClickDelete(View view){
        //System.out.println("We made it here! " + compte.getTypeCompte());
        Intent intent = new Intent(getApplicationContext(), DeleteAccountActivity.class);
        startActivity(intent);

    }

    //Onclick méthode qui termine l'activity.
    //Cette méthode est appelé lorsque l'utilisateur click le bouton Log out.
    public void onClickLogOut(View view){
        finish();
    }
}