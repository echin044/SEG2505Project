package com.example.projetseg2505;

import java.io.Serializable;

public class TextboxField implements Serializable {
    private String name;
    private String hint;

    public TextboxField(String name, String hint) {
        this.name = name;
        this.hint = hint;
    }

    public TextboxField(String name) {
        this.name = name;
        this.hint = "";
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getHint() {
        return hint;
    }

    public void setHint(String hint) {
        this.hint = hint;
    }
}
