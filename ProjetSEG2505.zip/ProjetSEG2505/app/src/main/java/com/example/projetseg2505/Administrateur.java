package com.example.projetseg2505;
import android.content.Intent;
import android.view.View;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.Serializable;
import java.util.ArrayList;

import androidx.annotation.NonNull;

public class Administrateur extends Compte{

    //Variable final de la classe.
    private final String TYPE_COMPTE = "ADMIN";

    private static FirebaseDatabase database = FirebaseDatabase.getInstance();
    private DatabaseReference dataReference = database.getReference("User");


    //Constructeur au moment de la création du compte administrateur.
    public Administrateur(String Username, String Password)
    {
        super(Username, Password);
    }


    //Méthodes pour accéder aux informations privées de l'administrateur
    public String getTypeCompte(){return TYPE_COMPTE;}


    public static void deleteAccount(String username){
        DatabaseReference dataReference = database.getReference("User");

        dataReference.child(username).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                if(snapshot.child("password").getValue() == null) {
                    //Toast.makeText(getApplicationContext(),"Hello Javatpoint",Toast.LENGTH_SHORT).show();
                    System.out.println("Aucun compte avec ce nom existe");
                }else if(snapshot.child("Type de compte").getValue().toString().equals("ADMIN")){
                    System.out.println("Vous ne pouvez pas supprimer un compte administrateur");
                }else{
                    dataReference.child(username).child("password").removeValue();
                    dataReference.child(username).child("Type de compte").removeValue();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });

    }

}
