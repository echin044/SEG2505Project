package com.example.projetseg2505;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

public class SignupActivity extends AppCompatActivity {

    //Variables de la base de données Firebase.
    private  FirebaseDatabase database = FirebaseDatabase.getInstance();

    //Variables des TextView, EditText et Switch qui changent pendant l'exécution.
    private EditText usernameText;
    private EditText passwordText;
    private TextView errorMsg;
    private Switch toggle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        //Initialisation des variables des TextView, EditText et Switch.
        usernameText = (EditText) findViewById(R.id.txtUsername);
        passwordText = (EditText) findViewById(R.id.txtPassword);
        errorMsg = (TextView) findViewById(R.id.txtvError);
        toggle = (Switch) findViewById(R.id.AccountToggle);
    }

    //Onclick méthode qui essaie de créer un compte en utilisant le mot de passe et le username fourni.
    //Cette méthode est appelé lorsque l'utilisateur click le bouton Créer.
    public void onClickCreate(View view)
    {
        //Vérifie si l'utilisateur a entré un username et un mot de passe.
        if(!usernameText.getText().toString().trim().isEmpty() && !passwordText.getText().toString().trim().isEmpty())//On peut ajouter des parametres de validation
        {
            //Vérifie si le nom d'utilisateur et le mot de passe ont des espaces.
            if(!usernameText.getText().toString().trim().matches(".*\\s+.*") && !passwordText.getText().toString().matches(".*\\s+.*"))
            {
                //Vérifie si le mot de passe est au moins 4 caractères. Si oui ont appèle la méthode createAccount()
                if (passwordText.getText().toString().length() > 4)
                    createAccount();

                //Si le mot de passe est 4 caractères ou moins, ce bloque else affiche un texte d'erreur.
                else {
                    errorMsg.setText("Le mot de passe nécessite au moins 5 caractères");
                    errorMsg.setVisibility(View.VISIBLE);
                }

            //S'il y a des espaces dans le nom d'utilisateur ou mot de passe, ce bloque else affiche un texte d'erreur.
            }else{
                errorMsg.setText("Svp assurez-vous qu'il n'y a pas d'espace dans le nom d'utilisateur et le mot de passe.");
                errorMsg.setVisibility(View.VISIBLE);
            }

        //L'utilisateur n'a pas entré toutes les informations nécessaires. Affiche un text d'erreur.
        }else{
            //On peut Ajouter code pour dire a l'utilisateur qu'il faut mettre un username et password
            errorMsg.setText("Svp entrez un nom d'utilisateur et un mot de passe.");
            errorMsg.setVisibility(View.VISIBLE);
        }
    }

    //Ajoute un nouveau compte dans la base de données.
    private void databaseEntry(String username, String password, String accountType) {
        DatabaseReference addUserInfo = database.getReference("User/" + username);
        addUserInfo.child("password").setValue(password);
        addUserInfo.child("Type de compte").setValue(accountType);
    }

    //Cherche la base de données Firebase. Si le nom d'utilisateur fouri ne s'y retrouve pas, un nouveau compte est créé.
    private void createAccount(){

        //Une référence aux utilisateurs dans la aase de données.
        DatabaseReference dataReference = database.getReference("User");

        //Ce bloque de code cherche dans la base de données pour le nom d'utilisateur fourni et attache cette référence à la variable snapshot.
        //La variable snapshot peut donc être utilisé pour récuper les information lier à ce compte.
        dataReference.child(usernameText.getText().toString().trim()).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                //Si le nom d'utilisateur n'existe pas dans la base de données, un nouveau compte est créé.
                if(snapshot.child("password").getValue() == null) {
                    Intent intent;

                    //Le nom d'utilisateur et mot de passe fourni sont mise dans des nouvelles variables
                    String username = usernameText.getText().toString().trim();
                    String password = passwordText.getText().toString();

                    //Vérifie si l'utilisateur veut créer un compte client ou employé en utilisant la Switch, puis créé un nouveau compte.
                    //Ce nouveau compte s'ouvre puis cette activity se ferme.
                    if(toggle.isChecked()){
                        Compte e = new Employe(username, password);
                        intent = new Intent(getApplicationContext(), EmployeActivity.class);
                        databaseEntry(username, password, "EMPLOYE");
                    }else{
                        Compte c = new Client(username, password);
                        intent = new Intent(getApplicationContext(), ClientActivity.class);
                        databaseEntry(username, password, "CLIENT");
                    }
                    intent.putExtra("username", username);
                    startActivity(intent);
                    finish();

                //Si le nom d'utilisateur existe dans la base de données, ce bloque else affiche un texte d'erreur.
                }else{
                    errorMsg.setText("Le nom d'utilisateur existe déjà. Svp choisir un nom différent");
                    errorMsg.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }

}