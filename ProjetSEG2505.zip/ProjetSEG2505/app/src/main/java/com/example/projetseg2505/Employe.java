package com.example.projetseg2505;

public class Employe extends Compte{

    //Variable final de la classe.
    private final String TYPE_COMPTE = "EMPLOYE";

    //Variable de la classe.
    private String succursale;


    //Constructeur au moment de la création du compte employé.
    public Employe(String Username, String Password)
    {
        super(Username, Password);
    }


    //méthodes pour accéder aux informations privées de l'employé
    public String getTypeCompte(){return TYPE_COMPTE;}

}
