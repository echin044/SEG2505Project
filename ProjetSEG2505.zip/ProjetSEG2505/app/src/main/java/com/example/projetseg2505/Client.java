package com.example.projetseg2505;

import java.util.ArrayList;

public class Client extends Compte {

    //Variable final de la classe.
    private final String TYPE_COMPTE = "CLIENT";


    //Constructeur au moment de la création du compte client.
    public Client(String Username, String Password)
    {
        super(Username, Password);
    }


    //Méthodes pour accéder aux informations privées du client
    public String getTypeCompte(){return TYPE_COMPTE;}


    //Méthode qui seront créés plus tard
	/*private CarteSanté();
	private PermisDeConduire();
	private PièceIDPhoto();*/
}
