package com.example.projetseg2505;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class UploadImageAdapter extends ArrayAdapter<String> {
    private Context context;
    private int resource;
    private ArrayList<String> list;

    public UploadImageAdapter(@NonNull Context context, int resource, @NonNull ArrayList<String> objects) {
        super(context, resource, objects);
        this.context = context;
        this.resource = resource;
        this.list = objects;
    }



    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        String name = getItem(position);

        LayoutInflater inflater = LayoutInflater.from(context);
        convertView = inflater.inflate(resource,parent, false);

        TextView fieldName = (TextView) convertView.findViewById(R.id.txtvFieldName);
        ImageView image = (ImageView) convertView.findViewById(R.id.imageUpload);
        Button btnDelete = (Button) convertView.findViewById(R.id.btnDelete);

        fieldName.setText(name);
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                list.remove(getItem(position));
                notifyDataSetChanged();
            }
        });

        image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                context.startActivity(intent);
            }
        });


        return convertView;
    }
}
