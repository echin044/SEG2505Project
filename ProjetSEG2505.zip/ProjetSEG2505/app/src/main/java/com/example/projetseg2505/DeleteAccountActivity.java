package com.example.projetseg2505;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.EditText;

public class DeleteAccountActivity extends AppCompatActivity {
    Administrateur compte;
    EditText username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_account);

        username = (EditText) findViewById(R.id.txtUsername);
    }

    public void onClickDelete(View view){

        Administrateur.deleteAccount(username.getText().toString());
    }
}