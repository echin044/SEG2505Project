package com.example.projetseg2505;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class TextboxFieldAdapter extends ArrayAdapter<TextboxField> {
    private Context context;
    private int resource;
    private ArrayList<TextboxField> list;

    public TextboxFieldAdapter(@NonNull Context context, int resource, @NonNull ArrayList<TextboxField> objects) {
        super(context, resource, objects);
        this.context = context;
        this.resource = resource;
        this.list = objects;
    }



    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        String name = getItem(position).getName();
        String hint = getItem(position).getHint();

        LayoutInflater inflater = LayoutInflater.from(context);
        convertView = inflater.inflate(resource,parent, false);

        TextView fieldName = (TextView) convertView.findViewById(R.id.txtvFieldName);
        EditText fieldInput = (EditText) convertView.findViewById(R.id.txtFieldInput);
        Button btnDelete = (Button) convertView.findViewById(R.id.btnDelete);

        fieldName.setText(name);
        fieldInput.setHint(hint);
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                list.remove(getItem(position));
                notifyDataSetChanged();
            }
        });


        return convertView;
    }
}
