package com.example.projetseg2505;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class ServiceListAdapter extends ArrayAdapter<Service> {

    private Context context;
    private int resource;
    private ArrayList<Service> list;

    public ServiceListAdapter(@NonNull Context context, int resource, @NonNull ArrayList<Service> objects) {
        super(context, resource, objects);
        this.context = context;
        this.resource = resource;
        list = objects;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        String name = getItem(position).getName();


        LayoutInflater inflater = LayoutInflater.from(context);
        convertView = inflater.inflate(resource,parent, false);

        TextView tvName = (TextView) convertView.findViewById(R.id.txtVService);
        Button btnDelete = (Button) convertView.findViewById(R.id.btnDelete);

        tvName.setText(name);
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                System.out.println("Hello! I am " + name);
                list.remove(getItem(position));
                notifyDataSetChanged();
            }
        });


        return convertView;
    }
}
