package com.example.projetseg2505;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class ServiceActivity extends AppCompatActivity{

    private AlertDialog.Builder dialogBuilder;
    private AlertDialog dialog;

    private EditText textPopupAddFieldName, textPopupAddFieldHint;
    private Button buttonPopupAddField;

    private RadioGroup radioGroup;

    ListView listViewTextbox, listViewImageUpload;
    TextView textTitle;
    int serviceID;
    TextboxFieldAdapter textboxAdapter;
    UploadImageAdapter uploadImageAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service);


        serviceID = (int) getIntent().getIntExtra("ServiceID", 0);
        listViewTextbox = (ListView) findViewById(R.id.listViewTextbox);
        listViewImageUpload = (ListView) findViewById(R.id.listViewImageUpload);
        textTitle =  findViewById(R.id.txtvTitle);
        textTitle.setText(Service.getListService().get(serviceID).getName());


        textboxAdapter = new TextboxFieldAdapter(this, R.layout.layout_textbox, Service.getListService().get(serviceID).getTextboxFieldList());
        listViewTextbox.setAdapter(textboxAdapter);

        uploadImageAdapter = new UploadImageAdapter(this, R.layout.layout_image_upload, Service.getListService().get(serviceID).getUploadImageFieldList());
        listViewImageUpload.setAdapter(uploadImageAdapter);
    }

    public void onClickFinish(View view){
        finish();
    }

    public void onClickAddField(View view){

        dialogBuilder = new AlertDialog.Builder(this);
        final View addFieldPopupView = getLayoutInflater().inflate(R.layout.popup_add_field, null);

        radioGroup = addFieldPopupView.findViewById(R.id.radioGroupID);

        textPopupAddFieldName = addFieldPopupView.findViewById(R.id.txtPopupAddFieldName);
        textPopupAddFieldHint = addFieldPopupView.findViewById(R.id.txtPopupAddFieldHint);
        buttonPopupAddField = addFieldPopupView.findViewById(R.id.btnPopupAddField);

        dialogBuilder.setView(addFieldPopupView);
        dialog = dialogBuilder.create();
        dialog.show();

        buttonPopupAddField.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int selectedRadioID =  radioGroup.getCheckedRadioButtonId();
                int textboxRadioID = R.id.rdioTextboxField;
                int uploadImageRadioID =  R.id.rdioImageUploadField;

                if(selectedRadioID == textboxRadioID){
                    Service.getListService().get(serviceID).addTextboxField(textPopupAddFieldName.getText().toString().trim(),textPopupAddFieldHint.getText().toString().trim());
                }else if(selectedRadioID == uploadImageRadioID){
                    Service.getListService().get(serviceID).addUploadImageField(textPopupAddFieldName.getText().toString().trim());
                }


                runOnUiThread(new Runnable() {
                    public void run() {
                        textboxAdapter.notifyDataSetChanged();
                    }
                });
                dialog.dismiss();
            }
        });




    }

}