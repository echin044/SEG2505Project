package com.example.projetseg2505;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    //Variables de la base de données Firebase.
    private  FirebaseDatabase database = FirebaseDatabase.getInstance();

    //Variables des TextView et EditText qui changent pendant l'exécution.
    private EditText usernameText;
    private EditText passwordText;
    private TextView errorMsg;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Initialisation des variables des TextView et EditText.
        usernameText = (EditText) findViewById(R.id.txtUsername);
        passwordText = (EditText) findViewById(R.id.txtPassword);
        errorMsg = (TextView) findViewById(R.id.txtvError);
    }


    //Onclick méthode qui essaie d'ouvrir un compte en utilisant le mot de passe et le username fourni.
    //Cette méthode est appelé lorsque l'utilisateur click le bouton Login.
    public void onClickLogin(View view)
    {
        //Vérifie si l'utilisateur a entré un username et un mot de passe.
        if(!usernameText.getText().toString().trim().isEmpty() && !passwordText.getText().toString().trim().isEmpty())//On peut ajouter des parametres de validation
        {
            findAccount();

        //L'utilisateur n'a pas entré toutes les informations nécessaires. Affiche un text d'erreur.
        }else
        {
            errorMsg.setText("Svp entrez un nom d'utilisateur et un mot de passe.");
            errorMsg.setVisibility(View.VISIBLE);
        }
    }

    //Cree un compte client
    public void onClickSignup(View view)
    {
        Intent intent = new Intent(getApplicationContext(), SignupActivity.class);
        startActivity(intent);

        resetTextFields();
    }

    //Réinitialise les TextView et EditText.
    private void resetTextFields(){
        usernameText.setText("");
        passwordText.setText("");
        errorMsg.setVisibility(View.INVISIBLE);
    }

    //Cherche la base de données Firebase. Si l'information fouri s'y retrouve, le compte s'ouvre.
    private void findAccount(){

        //Une référence aux utilisateurs dans la aase de données.
        DatabaseReference dataReference = database.getReference("User");

        //Ce bloque de code cherche dans la base de données pour le nom d'utilisateur fourni et attache cette référence à la variable snapshot.
        //La variable snapshot peut donc être utilisé pour récuper les information lier à ce compte.
        dataReference.child(usernameText.getText().toString().trim()).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                //Le if détermine si le nom d'utilisateur et le mot de passe existe dans la base de données Firebase.
                if(passwordText.getText().toString().equals(snapshot.child("password").getValue())) {
                    Intent intent;

                    //Le switch case détermine le type de compte de l'utilisateur puis ouvre leur compte.
                    switch (snapshot.child("Type de compte").getValue().toString()){
                        case "CLIENT": intent = new Intent(getApplicationContext(), ClientActivity.class);
                            intent.putExtra("username", usernameText.getText().toString().trim());
                            startActivity(intent);
                            break;
                        case "EMPLOYE": intent = new Intent(getApplicationContext(), EmployeActivity.class);
                            intent.putExtra("username", usernameText.getText().toString().trim());
                            startActivity(intent);
                            break;
                        case "ADMIN": intent = new Intent(getApplicationContext(), AdminActivity.class);
                            intent.putExtra("username", usernameText.getText().toString().trim());
                            startActivity(intent);
                            break;
                        default: break;
                    }
                    resetTextFields();

                //Si l'utilisateur a entré un nom d'utilisateur ou mot de passe icorrecte, ce bloque else affiche un texte d'erreur.
                }else{
                    errorMsg.setText("L'info fourni est incorrect");
                    errorMsg.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }


}

