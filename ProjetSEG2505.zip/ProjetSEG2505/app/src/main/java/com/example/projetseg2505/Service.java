package com.example.projetseg2505;

import java.io.Serializable;
import java.util.ArrayList;

public class Service implements Serializable {
    private String name;
    private ArrayList<TextboxField> textboxFieldList;
    private ArrayList<String> uploadImageFieldList;

    private static ArrayList<Service> listServices = new ArrayList<>();


    public Service(String name) {
        this.name = name;
        textboxFieldList = new ArrayList<>();
        uploadImageFieldList = new ArrayList<>();
        createDefaultService(this);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ArrayList<TextboxField> getTextboxFieldList() {
        return textboxFieldList;
    }

    public ArrayList<String> getUploadImageFieldList() {
        return uploadImageFieldList;
    }

    public void addTextboxField(String itemName, String itemHint){
        textboxFieldList.add(new TextboxField(itemName, itemHint));
    }
    public void addTextboxField(String itemName){
        textboxFieldList.add(new TextboxField(itemName));
    }

    public void addUploadImageField(String itemName){
        uploadImageFieldList.add(itemName);
    }



    private static void createDefaultService(Service service){
        service.addTextboxField("Prénom:");
        service.addTextboxField("Nom:");
        service.addTextboxField("Adresse:");
        service.addTextboxField("Date de naissance:");
        service.addUploadImageField("Preuve de domicile: ");
    }


    public static ArrayList<Service> getListService() {
        return listServices;
    }



    public static void addService(Service newService) {
        listServices.add(newService);
    }

}
