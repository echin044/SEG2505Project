package com.example.projetseg2505;

import java.io.Serializable;
import java.util.ArrayList;

public abstract class Compte implements Serializable {

    //Variable d'instance de la classe.
    protected String username;
    protected String password;

    //Variable static de la classe.
    protected static ArrayList<Compte> listOfComptes = new ArrayList<Compte>();


    //Constructeur au moment de la création du
    public Compte(String Username, String Password)
    {
        username = Username;
        password = Password;
        listOfComptes.add(this);
    }

    //méthodes pour accéder aux informations privées de l'utilisteur
    public void setUsername(String s)
    {
        username = s;
    }

    public String getUsername()
    {
        return username;
    }

    public void setPassword(String s)
    {
        password = s;
    }

    public String getPassword() { return password; }

    public abstract String getTypeCompte();


    //Constructeur au moment de la création d'un compte.
    public static Compte findCompte(String name){
        for(Compte c : listOfComptes){
            if(c.getUsername().equals(name)) {
                return c;
            }
        }
        return null;
    }

    //Retourne true si et seulement si le mot de passe est correct.
    public boolean isCorrectPassword(String pass){
        return (this.getPassword().equals(pass));
    }

}
