package com.example.projetseg2505;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;

import java.io.Serializable;
import java.util.ArrayList;

public class ServiceListActivity extends AppCompatActivity {
    //Button btn1, btn2, btn3, btn4, btn5 ;

    ListView listView;
    EditText serviceName;
    ArrayList<Service> listServices;
    ServiceListAdapter adapter;
    Service carteSante;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service_list);


        listView = (ListView) findViewById(R.id.listView);
        serviceName = (EditText) findViewById(R.id.txtServiceName);

        Service passport = new Service("Passport");
        Service permitDeConduire = new Service("Permit de conduire");
        carteSante = new Service("Carte de santé");


        listServices = new ArrayList<>();
        Service.addService(passport);
        Service.addService(permitDeConduire);
        Service.addService(carteSante);



        adapter = new ServiceListAdapter(this, R.layout.services_adapter_layout, Service.getListService());
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(getApplicationContext(), ServiceActivity.class);
                intent.putExtra("ServiceID", i);
                startActivity(intent);
            }
        });


    }

    public void onClickAddService(View view){

        if(!serviceName.getText().toString().trim().isEmpty())
        {
            Service.addService(new Service(serviceName.getText().toString().trim()));
            runOnUiThread(new Runnable() {
                public void run() {
                    adapter.notifyDataSetChanged();
                }
            });
            resetTextFields();
        }
    }

    private void resetTextFields(){
        serviceName.setText("");
    }

}